const translate = require('google-translate-api');

var params = [];
var i = 0;
var str = "";

process.argv.forEach(function(val, index, array) {
	if (i < 3) {
		params.push(val);
		i++;
	} else {
		str += val + ' ';
	}
});

params.push(str);

translate(params[3], {to: params[2]}).then(res => {
	console.log(res.text);
});